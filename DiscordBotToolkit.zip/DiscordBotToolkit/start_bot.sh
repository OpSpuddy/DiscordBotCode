#!/bin/bash
# This script starts the Discord bot using the run.py wrapper
python3 run.py