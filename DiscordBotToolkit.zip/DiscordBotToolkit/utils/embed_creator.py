import discord
from datetime import datetime
import config

def create_announcement_embed(announcement_type, member, reason, issued_by):
    """
    Create an embed for announcements.
    
    Parameters:
    -----------
    announcement_type: Type of announcement (promotion, demotion, etc.)
    member: The discord Member the announcement is about
    reason: The reason for the announcement
    issued_by: The discord Member who issued the announcement
    
    Returns:
    --------
    discord.Embed: The formatted embed for the announcement
    """
    # Determine color and title based on announcement type
    color = config.COLORS.get(announcement_type, config.COLORS["default"])
    
    # Get current time for the footer
    timestamp = datetime.now()
    
    # Create the base embed
    embed = discord.Embed(
        color=color,
        timestamp=timestamp
    )
    
    # Set author to the person issuing the announcement
    embed.set_author(
        name=f"{issued_by.display_name}",
        icon_url=issued_by.display_avatar.url
    )
    
    # Add footer with server name
    if issued_by.guild:
        embed.set_footer(
            text=f"{issued_by.guild.name}",
            icon_url=issued_by.guild.icon.url if issued_by.guild.icon else None
        )
    
    # Set up the title and description based on the announcement type
    if announcement_type == "promotion":
        embed.title = "🔼 Member Promotion"
        embed.description = f"**{member.mention}** has been promoted!"
        
    elif announcement_type == "demotion":
        embed.title = "🔽 Member Demotion"
        embed.description = f"**{member.mention}** has been demoted."
        
    elif announcement_type == "warning":
        embed.title = "⚠️ Member Warning"
        embed.description = f"**{member.mention}** has received a warning."
        
    elif announcement_type == "commendation":
        embed.title = "🏆 Member Commendation"
        embed.description = f"**{member.mention}** has been commended!"
        
    elif announcement_type == "announcement":
        embed.title = "📢 Server Announcement"
        embed.description = reason
        return embed  # No need for additional fields for general announcements
    
    # Add member information if applicable
    if member:
        embed.add_field(
            name="Member",
            value=f"{member.mention} ({member.name}#{member.discriminator})",
            inline=True
        )
        
        # Add member joined date
        embed.add_field(
            name="Member Since",
            value=f"<t:{int(member.joined_at.timestamp())}:R>",
            inline=True
        )
        
        # Add member avatar as thumbnail
        embed.set_thumbnail(url=member.display_avatar.url)
    
    # Add reason if provided
    if reason:
        embed.add_field(
            name="Reason",
            value=reason,
            inline=False
        )
    
    return embed
