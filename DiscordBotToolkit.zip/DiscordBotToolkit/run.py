#!/usr/bin/env python3

# This script runs the Discord bot
# We use this instead of main.py directly to avoid conflicts with the gunicorn server

import os
import sys
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger('discord_bot_runner')

def run_bot():
    """Run the Discord bot from main.py"""
    logger.info("Starting Discord bot...")
    
    # Check if Discord token is set
    if not os.environ.get("DISCORD_TOKEN"):
        logger.error("DISCORD_TOKEN environment variable is not set. Please set it and try again.")
        return
    
    logger.info("Discord token found, running bot...")
    
    # Import and run the bot
    try:
        import main
        logger.info("Bot started successfully!")
    except Exception as e:
        logger.error(f"Error starting bot: {e}")

if __name__ == "__main__":
    run_bot()