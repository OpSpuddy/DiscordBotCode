# No command prefix needed for slash commands
COMMAND_PREFIX = "/"

# We're not using traditional cogs anymore with slash commands
EXTENSIONS = []

# Your server IDs for registering slash commands (add your server IDs here)
SERVER_IDS = [
    1367548201774743562  # Liberty County Roleplay | ERLC server
]

# Embed colors for different announcement types (in decimal format)
COLORS = {
    "promotion": 0x3498db,    # Blue
    "demotion": 0xe74c3c,     # Red
    "warning": 0xf1c40f,      # Yellow
    "commendation": 0x2ecc71, # Green
    "announcement": 0x9b59b6, # Purple
    "default": 0x95a5a6       # Gray
}

# Role names that are allowed to use admin announcement commands
# These will be checked case-insensitively
ADMIN_ROLES = [
    "LCRP I Management",
    "LCRP I HR Staff",
    "Admin",
    "Moderator",
    "Staff",
    "Management"
]

# Maximum length for announcement reason
MAX_REASON_LENGTH = 1024  # Discord embed field limit
