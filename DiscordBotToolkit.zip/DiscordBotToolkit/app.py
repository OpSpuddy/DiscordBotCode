import os
import logging
import subprocess
import threading
import time
from flask import Flask, render_template_string, jsonify

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('discord_bot_app')

app = Flask(__name__)

# Bot process - we're running it directly in main.py now
bot_process = None
bot_status = "Running"  # Set to Running since the bot starts automatically

# Add a function to capture discord logs
import os
import re

def get_discord_logs():
    """Get latest log entries from the Discord bot"""
    logs = ["Bot started automatically on server startup"]
    
    try:
        # Read the current workflow log file - we don't have direct access to discord logs
        # but can parse them from workflow logs
        log_pattern = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - (admin_announcer|discord\.\w+) - (\w+) - (.+)$')
        
        # Use the ps command to check for the bot process
        with os.popen('ps aux | grep "gunicorn" | grep -v grep') as p:
            process_running = p.read().strip()
            if not process_running:
                logs.append("Warning: Bot server process not found")
        
        # Try to get some basic status info
        with os.popen('ps aux | grep "python" | grep -v grep') as p:
            processes = p.read().strip()
            logs.append(f"Active Python processes: {processes.count('python')}")
    
    except Exception as e:
        logs.append(f"Error getting logs: {str(e)}")
    
    return logs

# Initialize log with captured discord logs
bot_log = get_discord_logs()

def run_bot():
    """Run the Discord bot in a separate process and capture output"""
    global bot_process, bot_status, bot_log
    
    bot_log.clear()
    bot_log.append("Starting Discord bot...")
    
    try:
        # Run the bot using run.py
        bot_process = subprocess.Popen(
            ["python3", "run.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        
        bot_status = "Running"
        bot_log.append("Bot process started")
        
        # Read output
        for line in bot_process.stdout:
            bot_log.append(line.strip())
            if len(bot_log) > 100:  # Keep only last 100 lines
                bot_log.pop(0)
        
        # Process ended
        return_code = bot_process.wait()
        if return_code != 0:
            bot_status = f"Crashed (exit code {return_code})"
        else:
            bot_status = "Stopped"
        
    except Exception as e:
        bot_status = f"Error: {str(e)}"
        bot_log.append(f"Error running bot: {e}")

# HTML template for the status page
STATUS_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Discord Admin Announcer Bot - Status</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
        }
        .log-container {
            background-color: var(--bs-gray-900);
            border-radius: 6px;
            padding: 10px;
            height: 400px;
            overflow-y: auto;
            font-family: monospace;
            white-space: pre-wrap;
            margin-bottom: 20px;
        }
        .log-line {
            margin: 0;
            padding: 2px 0;
        }
        .btn-control {
            margin-right: 10px;
        }
        .status-badge {
            font-size: 1rem;
            padding: 0.5rem 0.75rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-4 mb-4">Discord Admin Announcer Bot</h1>
        
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Bot Status</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <span class="me-2">Status:</span>
                                <span id="status-badge" class="badge rounded-pill bg-{{status_color}}">{{status}}</span>
                            </div>
                            <div>
                                <button id="start-btn" class="btn btn-success btn-control" {{start_disabled}}>Start Bot</button>
                                <button id="stop-btn" class="btn btn-danger btn-control" {{stop_disabled}}>Stop Bot</button>
                                <button id="refresh-btn" class="btn btn-secondary btn-control">Refresh</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Bot Log</h5>
            </div>
            <div class="card-body">
                <div class="log-container" id="log-container">
                    {% for line in log %}
                    <div class="log-line">{{line}}</div>
                    {% endfor %}
                </div>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Available Commands</h5>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Command</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>/promote @member [reason]</code></td>
                            <td>Send a promotion announcement for a member</td>
                        </tr>
                        <tr>
                            <td><code>/demote @member [reason]</code></td>
                            <td>Send a demotion announcement for a member</td>
                        </tr>
                        <tr>
                            <td><code>/warn @member [reason]</code></td>
                            <td>Send a warning announcement for a member</td>
                        </tr>
                        <tr>
                            <td><code>/commend @member [reason]</code></td>
                            <td>Send a commendation announcement for a member</td>
                        </tr>
                        <tr>
                            <td><code>/announce message</code></td>
                            <td>Send a general announcement to the server</td>
                        </tr>
                        <tr>
                            <td><code>/help</code></td>
                            <td>Show help information for commands</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        // Client-side JavaScript for controlling the bot
        document.getElementById('start-btn').addEventListener('click', function() {
            fetch('/api/start', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.reload();
                    } else {
                        alert('Failed to start bot: ' + data.error);
                    }
                });
        });
        
        document.getElementById('stop-btn').addEventListener('click', function() {
            fetch('/api/stop', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.reload();
                    } else {
                        alert('Failed to stop bot: ' + data.error);
                    }
                });
        });
        
        document.getElementById('refresh-btn').addEventListener('click', function() {
            window.location.reload();
        });
        
        // Auto-scroll to bottom of log
        var logContainer = document.getElementById('log-container');
        logContainer.scrollTop = logContainer.scrollHeight;
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    """Main status page for the bot"""
    global bot_status, bot_log
    
    # Determine status color
    status_color = "secondary"
    if bot_status == "Running":
        status_color = "success"
    elif bot_status.startswith("Error") or bot_status.startswith("Crashed"):
        status_color = "danger"
    
    # Determine button states
    start_disabled = "disabled" if bot_status == "Running" else ""
    stop_disabled = "disabled" if bot_status != "Running" else ""
    
    return render_template_string(
        STATUS_PAGE,
        status=bot_status,
        status_color=status_color,
        log=bot_log,
        start_disabled=start_disabled,
        stop_disabled=stop_disabled
    )

@app.route('/api/start', methods=['POST'])
def api_start():
    """API endpoint to start the bot"""
    global bot_process, bot_status
    
    if bot_status == "Running":
        return jsonify({"success": False, "error": "Bot is already running"})
    
    # Start bot in a new thread
    bot_thread = threading.Thread(target=run_bot)
    bot_thread.daemon = True
    bot_thread.start()
    
    # Wait a moment for process to start
    time.sleep(1)
    
    return jsonify({"success": True})

@app.route('/api/stop', methods=['POST'])
def api_stop():
    """API endpoint to stop the bot"""
    global bot_process, bot_status
    
    if bot_status != "Running" or bot_process is None:
        return jsonify({"success": False, "error": "Bot is not running"})
    
    try:
        bot_process.terminate()
        bot_process.wait(timeout=5)
        bot_status = "Stopped"
        bot_log.append("Bot stopped by user")
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/api/status')
def api_status():
    """API endpoint to get bot status"""
    global bot_status, bot_log
    
    return jsonify({
        "status": bot_status,
        "log": bot_log
    })

if __name__ == "__main__":
    # For local development
    app.run(debug=True, host='0.0.0.0', port=5000)