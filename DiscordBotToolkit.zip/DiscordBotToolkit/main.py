import os
import logging
import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import Modal, TextInput
from discord.utils import get

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("staff_bot")

# Intents
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# Role check decorators
def is_authorized():
    async def predicate(interaction: discord.Interaction):
        member = interaction.user
        if not isinstance(member, discord.Member):
            member = await interaction.guild.fetch_member(member.id)
        return any(role.name in ("LCRP | HR Staff", "LCRP | Management") for role in member.roles)
    return app_commands.check(predicate)

def is_hr():
    async def predicate(interaction: discord.Interaction):
        member = interaction.user
        if not isinstance(member, discord.Member):
            member = await interaction.guild.fetch_member(member.id)
        return any(role.name == "LCRP | HR Staff" for role in member.roles)
    return app_commands.check(predicate)

# Bot class
class StaffBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        guild = discord.Object(id=1367548201774743562)
        self.tree.copy_global_to(guild=guild)
        await self.tree.sync(guild=guild)

bot = StaffBot()

# Slash command: /commands
@bot.tree.command(name="commands", description="List all staff commands", guild=discord.Object(id=1367548201774743562))
@is_authorized()
async def commands_cmd(interaction: discord.Interaction):
    embed = discord.Embed(title="Staff Bot Commands", color=discord.Color.blue())
    embed.add_field(name="/commands", value="List all available commands", inline=False)
    embed.add_field(name="/feedback", value="Submit staff feedback for HR review", inline=False)
    embed.add_field(name="/infraction", value="Log a staff infraction", inline=False)
    embed.add_field(name="/promote", value="Log a staff promotion", inline=False)
    embed.add_field(name="/purge", value="Delete bulk messages", inline=False)
    embed.add_field(name="/add-roles", value="Add up to 10 roles to a user", inline=False)
    embed.add_field(name="/remove-roles", value="Remove up to 10 roles from a user", inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)

# Slash command: /purge
@bot.tree.command(name="purge", description="Delete messages in bulk", guild=discord.Object(id=1367548201774743562))
@is_authorized()
async def purge_cmd(interaction: discord.Interaction, amount: int):
    await interaction.channel.purge(limit=amount)
    await interaction.response.send_message(f"🧹 Deleted {amount} messages.", ephemeral=True)

# Slash command: /promote
@bot.tree.command(name="promote", description="Log a promotion", guild=discord.Object(id=1367548201774743562))
@is_hr()
async def promote_cmd(interaction: discord.Interaction, member: discord.Member, new_role: str):
    await interaction.response.send_message(f"✅ {member.mention} has been promoted to **{new_role}**!", ephemeral=False)

# Slash command: /infraction
@bot.tree.command(name="infraction", description="Log an infraction", guild=discord.Object(id=1367548201774743562))
@is_hr()
async def infraction_cmd(interaction: discord.Interaction, member: discord.Member, reason: str):
    await interaction.response.send_message(f"⚠️ Infraction logged for {member.mention}:\n**Reason:** {reason}", ephemeral=False)

# Modal: Feedback
class FeedbackModal(Modal, title="Staff Feedback"):
    feedback = TextInput(label="Your Feedback", style=discord.TextStyle.paragraph, required=True, max_length=1000)

    async def on_submit(self, interaction: discord.Interaction):
        feedback_channel = get(interaction.guild.text_channels, name="📬│staff-feedback")
        if feedback_channel:
            await feedback_channel.send(f"📝 New Feedback from {interaction.user.mention}:\n{self.feedback.value}")
        await interaction.response.send_message("✅ Feedback submitted. Thank you!", ephemeral=True)

# Slash command: /feedback
@bot.tree.command(name="feedback", description="Submit feedback to HR", guild=discord.Object(id=1367548201774743562))
@is_authorized()
async def feedback_cmd(interaction: discord.Interaction):
    await interaction.response.send_modal(FeedbackModal())

# Slash command: /add-roles
@bot.tree.command(name="add-roles", description="Add roles to a user", guild=discord.Object(id=1367548201774743562))
@is_hr()
async def add_roles_cmd(interaction: discord.Interaction, user: discord.Member, *roles: discord.Role):
    roles_to_add = [role for role in roles if role not in user.roles][:10]
    already_has = [role.mention for role in roles if role in user.roles]

    if roles_to_add:
        await user.add_roles(*roles_to_add)

    if already_has:
        await interaction.response.send_message(f"User already had: {', '.join(already_has)}", ephemeral=True)
    else:
        await interaction.response.send_message("✅ Roles added successfully.", ephemeral=True)

# Slash command: /remove-roles
@bot.tree.command(name="remove-roles", description="Remove roles from a user", guild=discord.Object(id=1367548201774743562))
@is_hr()
async def remove_roles_cmd(interaction: discord.Interaction, user: discord.Member, *roles: discord.Role):
    roles_to_remove = [role for role in roles if role in user.roles][:10]
    not_present = [role.mention for role in roles if role not in user.roles]

    if roles_to_remove:
        await user.remove_roles(*roles_to_remove)

    if not_present:
        await interaction.response.send_message(f"User didn't have: {', '.join(not_present)}", ephemeral=True)
    else:
        await interaction.response.send_message("✅ Roles removed successfully.", ephemeral=True)

# Welcome message
@bot.event
async def on_member_join(member):
    channel = get(member.guild.text_channels, name="👋│welcome")
    if channel:
        member_count = sum(1 for m in member.guild.members if not m.bot)
        suffix = "th"
        if 10 <= member_count % 100 <= 20:
            suffix = "th"
        elif member_count % 10 == 1:
            suffix = "st"
        elif member_count % 10 == 2:
            suffix = "nd"
        elif member_count % 10 == 3:
            suffix = "rd"
        await channel.send(
            f"Hello {member.mention}! Welcome to LCRP! You're our {member_count}{suffix} member! "
            "We hope you enjoy our roleplays!"
        )

# Error handler
@bot.tree.error
async def on_app_command_error(interaction, error):
    if isinstance(error, app_commands.errors.CheckFailure):
        await interaction.response.send_message("❌ You are not authorized to use this command.", ephemeral=True)
    else:
        logger.error(f"Command error: {error}")
        await interaction.response.send_message(f"An error occurred: {error}", ephemeral=True)

# Run bot
if __name__ == "__main__":
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        logger.critical("❌ DISCORD_TOKEN not set in Replit Secrets!")
    else:
        bot.run(token)
