import discord
from discord import app_commands
import logging
from typing import Optional
import config
from utils.embed_creator import create_announcement_embed

logger = logging.getLogger('admin_announcer.announcement')

# Role names that are allowed to use announcement commands
REQUIRED_ROLES = ["LCRP I Management", "LCRP I HR Staff"]

def has_permission(interaction: discord.Interaction) -> bool:
    """Check if user has permission to use announcement commands."""
    if interaction.guild is None:
        return False
    
    # Always allow the bot owner or server owner
    try:
        if interaction.user.id == interaction.client.application.owner.id:
            return True
    except:
        # Application owner might not be available
        pass
        
    if interaction.guild.owner_id == interaction.user.id:
        return True
    
    # Debug log
    logger.info(f"Checking permissions for user: {interaction.user} (ID: {interaction.user.id})")
    
    # Check if user has any of the required roles (case-insensitive)
    member_role_names = [role.name.lower() for role in interaction.user.roles]
    required_role_names = [role.lower() for role in REQUIRED_ROLES]
    
    # Log user roles for debugging
    logger.info(f"User roles: {[role.name for role in interaction.user.roles]}")
    logger.info(f"Required roles: {REQUIRED_ROLES}")
    
    # Simple exact role name check
    for role in interaction.user.roles:
        if role.name in REQUIRED_ROLES:
            logger.info(f"Permission granted via exact role match: {role.name}")
            return True
    
    # Partial matching for flexibility
    for required_role in required_role_names:
        for user_role in member_role_names:
            if required_role in user_role:
                logger.info(f"Permission granted via partial role match: {user_role} contains {required_role}")
                return True
    
    # If user has Administrator permission, always allow
    try:
        if interaction.user.guild_permissions.administrator:
            logger.info(f"Permission granted via Administrator permission")
            return True
    except:
        pass
    
    logger.info(f"Permission denied for user: {interaction.user}")
    return False

def register_announcement_commands(tree):
    """Register all announcement slash commands with the command tree."""
    
    # Liberty County server ID
    guild_id = 1367548201774743562
    guild = discord.Object(id=guild_id)
    
    # Promote command
    @tree.command(
        name="promote",
        description="Send a promotion announcement for a member",
        guild=guild  # Register only to Liberty County server
    )
    async def promote(interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided"):
        """Send a promotion announcement."""
        if not has_permission(interaction):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
            return
            
        await _send_announcement(interaction, "promotion", member, reason)
    
    # Demote command
    @tree.command(
        name="demote",
        description="Send a demotion announcement for a member",
        guild=guild  # Register only to Liberty County server
    )
    async def demote(interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided"):
        """Send a demotion announcement."""
        if not has_permission(interaction):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
            return
            
        await _send_announcement(interaction, "demotion", member, reason)
    
    # Warn command
    @tree.command(
        name="warn",
        description="Send a warning announcement for a member",
        guild=guild  # Register only to Liberty County server
    )
    async def warn(interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided"):
        """Send a warning announcement."""
        if not has_permission(interaction):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
            return
            
        await _send_announcement(interaction, "warning", member, reason)
    
    # Commend command
    @tree.command(
        name="commend",
        description="Send a commendation announcement for a member",
        guild=guild  # Register only to Liberty County server
    )
    async def commend(interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided"):
        """Send a commendation announcement."""
        if not has_permission(interaction):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
            return
            
        await _send_announcement(interaction, "commendation", member, reason)
    
    # Announce command
    @tree.command(
        name="announce",
        description="Send a general announcement to the server",
        guild=guild  # Register only to Liberty County server
    )
    async def announce(interaction: discord.Interaction, message: str):
        """Send a general announcement."""
        if not has_permission(interaction):
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
            return
            
        embed = create_announcement_embed(
            announcement_type="announcement",
            member=None,
            reason=message,
            issued_by=interaction.user
        )
        
        # Defer response to avoid timeout since announcements can be large
        await interaction.response.defer(ephemeral=True)
        
        # Send the announcement to the channel
        await interaction.channel.send(embed=embed)
        
        # Send confirmation to the user
        await interaction.followup.send("Announcement sent successfully!", ephemeral=True)
        logger.info(f"Announcement sent by {interaction.user} in {interaction.channel}")

async def _send_announcement(interaction, announcement_type, member, reason):
    """Helper method to send announcement embeds."""
    # Truncate the reason if it's too long
    if reason and len(reason) > config.MAX_REASON_LENGTH:
        reason = f"{reason[:config.MAX_REASON_LENGTH-3]}..."
    
    embed = create_announcement_embed(
        announcement_type=announcement_type,
        member=member,
        reason=reason,
        issued_by=interaction.user
    )
    
    # Defer response to avoid timeout
    await interaction.response.defer(ephemeral=True)
    
    # Send the announcement to the channel
    await interaction.channel.send(embed=embed)
    
    # Send confirmation to the user
    await interaction.followup.send(f"{announcement_type.capitalize()} announcement sent successfully!", ephemeral=True)
    
    logger.info(f"{announcement_type.capitalize()} announcement for {member} sent by {interaction.user} in {interaction.channel}")