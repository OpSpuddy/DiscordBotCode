import discord
from discord import app_commands
import config

def register_help_commands(tree):
    """Register help slash commands with the command tree."""
    
    # Liberty County server ID
    guild_id = 1367548201774743562
    guild = discord.Object(id=guild_id)
    
    @tree.command(
        name="help",
        description="Show help information for commands",
        guild=guild  # Register only to Liberty County server
    )
    async def help_command(interaction: discord.Interaction):
        """Show help information for commands."""
        embed = discord.Embed(
            title="Administrative Announcer Help",
            description="Here are the available commands for the Administrative Announcer bot.",
            color=config.COLORS.get("default")
        )
        
        # Add field for announcement commands
        embed.add_field(
            name="Announcement Commands",
            value=(
                "`/promote @member [reason]` - Send a promotion announcement\n"
                "`/demote @member [reason]` - Send a demotion announcement\n"
                "`/warn @member [reason]` - Send a warning announcement\n"
                "`/commend @member [reason]` - Send a commendation announcement\n"
                "`/announce message` - Send a general announcement\n"
            ),
            inline=False
        )
        
        # Add permission requirements
        embed.add_field(
            name="Required Roles",
            value=", ".join(f"`{role}`" for role in ["LCRP I Management", "LCRP I HR Staff"]),
            inline=False
        )
        
        embed.set_footer(text="Administrative Announcer Bot")
        
        # Send as ephemeral message (only visible to the user who ran the command)
        await interaction.response.send_message(embed=embed, ephemeral=True)