import discord
from discord.ext import commands
import logging
from typing import Optional
import config
from utils.embed_creator import create_announcement_embed

logger = logging.getLogger('admin_announcer.announcement')

class AnnouncementCog(commands.Cog, name="Announcement Commands"):
    """Commands for creating and sending administrative announcements."""
    
    def __init__(self, bot):
        self.bot = bot
    
    async def cog_check(self, ctx):
        """Check if user has permission to use announcement commands."""
        if ctx.guild is None:
            return False
            
        # Check if user has any of the admin roles
        return any(role.name.lower() in [r.lower() for r in config.ADMIN_ROLES] 
                  for role in ctx.author.roles)
    
    @commands.command(name="promote")
    async def promote_command(self, ctx, member: discord.Member, *, reason: Optional[str] = "No reason provided"):
        """
        Send a promotion announcement.
        
        Parameters:
        -----------
        member: The member being promoted
        reason: The reason for the promotion (optional)
        """
        await self._send_announcement(ctx, "promotion", member, reason)
    
    @commands.command(name="demote")
    async def demote_command(self, ctx, member: discord.Member, *, reason: Optional[str] = "No reason provided"):
        """
        Send a demotion announcement.
        
        Parameters:
        -----------
        member: The member being demoted
        reason: The reason for the demotion (optional)
        """
        await self._send_announcement(ctx, "demotion", member, reason)
    
    @commands.command(name="warn")
    async def warn_command(self, ctx, member: discord.Member, *, reason: Optional[str] = "No reason provided"):
        """
        Send a warning announcement.
        
        Parameters:
        -----------
        member: The member being warned
        reason: The reason for the warning (optional)
        """
        await self._send_announcement(ctx, "warning", member, reason)
    
    @commands.command(name="commend")
    async def commend_command(self, ctx, member: discord.Member, *, reason: Optional[str] = "No reason provided"):
        """
        Send a commendation announcement.
        
        Parameters:
        -----------
        member: The member being commended
        reason: The reason for the commendation (optional)
        """
        await self._send_announcement(ctx, "commendation", member, reason)
    
    @commands.command(name="announce")
    async def announce_command(self, ctx, *, message: str):
        """
        Send a general announcement.
        
        Parameters:
        -----------
        message: The announcement message
        """
        embed = create_announcement_embed(
            announcement_type="announcement",
            member=None,
            reason=message,
            issued_by=ctx.author
        )
        
        await ctx.send(embed=embed)
        await ctx.message.delete()
        logger.info(f"Announcement sent by {ctx.author} in {ctx.channel}")
    
    async def _send_announcement(self, ctx, announcement_type, member, reason):
        """Helper method to send announcement embeds."""
        # Truncate the reason if it's too long
        if reason and len(reason) > config.MAX_REASON_LENGTH:
            reason = f"{reason[:config.MAX_REASON_LENGTH-3]}..."
        
        embed = create_announcement_embed(
            announcement_type=announcement_type,
            member=member,
            reason=reason,
            issued_by=ctx.author
        )
        
        await ctx.send(embed=embed)
        # Delete the command message to keep the channel clean
        await ctx.message.delete()
        
        logger.info(f"{announcement_type.capitalize()} announcement for {member} sent by {ctx.author} in {ctx.channel}")

async def setup(bot):
    await bot.add_cog(AnnouncementCog(bot))
