import discord
from discord.ext import commands
import config

class HelpCog(commands.Cog):
    """Custom help command implementation."""
    
    def __init__(self, bot):
        self.bot = bot
        # Remove default help command
        bot.remove_command('help')
    
    @commands.command(name="help")
    async def help_command(self, ctx, command_name: str = None):
        """
        Show help information for commands.
        
        Parameters:
        -----------
        command_name: Specific command to show help for (optional)
        """
        prefix = config.COMMAND_PREFIX
        
        if command_name:
            # Show help for a specific command
            command = self.bot.get_command(command_name)
            if command:
                embed = discord.Embed(
                    title=f"Help: {prefix}{command.name}",
                    description=command.help or "No description available.",
                    color=config.COLORS.get("default")
                )
                
                # Add usage information
                usage = f"{prefix}{command.name}"
                if command.signature:
                    usage += f" {command.signature}"
                embed.add_field(name="Usage", value=f"`{usage}`", inline=False)
                
                # Show permission requirements
                if command.cog_name == "Announcement Commands":
                    roles_str = ", ".join(f"`{role}`" for role in config.ADMIN_ROLES)
                    embed.add_field(name="Required Roles", value=roles_str, inline=False)
                
                await ctx.send(embed=embed)
            else:
                await ctx.send(f"Command `{command_name}` not found. Use `{prefix}help` to see all commands.")
        else:
            # Show general help with all commands
            embed = discord.Embed(
                title="Administrative Announcer Help",
                description=f"Use `{prefix}help <command>` for more details on a command.",
                color=config.COLORS.get("default")
            )
            
            # Group commands by cog
            for cog_name, cog in self.bot.cogs.items():
                # Skip listing help commands in help
                if cog_name == "HelpCog":
                    continue
                
                # Get commands from this cog
                cog_commands = cog.get_commands()
                if not cog_commands:
                    continue
                
                # Add field for this category
                command_list = []
                for command in cog_commands:
                    command_list.append(f"`{prefix}{command.name}`")
                
                embed.add_field(
                    name=cog_name,
                    value=", ".join(command_list),
                    inline=False
                )
            
            embed.set_footer(text="Administrative Announcer Bot")
            await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(HelpCog(bot))
